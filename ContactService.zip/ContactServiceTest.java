import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	   //Test add contact
	   @Test
	   public void testAdd() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(true, contactService.add(c2));

	   }

	   //Test for add failure
	   @Test
	   public void testAddFailure() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(false, contactService.add(c1));
	       assertEquals(true, contactService.add(c2));
	   }

	   //Test delete contact
	   @Test
	   public void testDelete() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(true, contactService.add(c2));
	       assertEquals(true, contactService.remove("CID123"));
	       assertEquals(true, contactService.remove("CID111"));
	   }

	   //Test for delete failure
	   @Test
	   public void testDeleteFailure() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(true, contactService.add(c2));
	       assertEquals(false, contactService.remove("CID222"));
	       assertEquals(true, contactService.remove("CID111"));
	   }

	   //Test update contact
	   @Test
	   public void testUpdate() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(true, contactService.add(c2));
	       assertEquals(true, contactService.update("CID123", "Janie", "Doe", "1234567890", "4 Tea St. Help, OH 12345"));
	       assertEquals(true, contactService.update("CID111", "Johnny", "Smith", "1112223333", "6 Sky St. Cloud, KS 45678"));
	   }

	   //Test for update failure
	   @Test
	   public void testUpdateFailure() {
	       ContactService contactService = new ContactService();
	       Contact c1 = new Contact("CID123", "Jane", "Doe", "1234567890", "2 Tea St. Help, OH 12345");
	       Contact c2 = new Contact("CID111", "John", "Smith", "1111111111", "3 Sky St. Cloud, KS 45678");
	       assertEquals(true, contactService.add(c1));
	       assertEquals(true, contactService.add(c2)); 
	       assertEquals(false, contactService.update("CID222", "Jill", "Mickey", "8888888888", "8 More Rd. Isle, MO 88888"));
	       assertEquals(true, contactService.update("CID111", "Johnny", "Smith", "1112223333", "6 Sky St. Cloud, KS 45678"));
	   }
}
