import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {

	//Test if input string is correctly assigned to each variable
	@Test
	public void TestContact() {
	    Contact contact = new Contact("CID001", "Jane", "Doe", "1234567890","2 Tea St. Help, OH 12345");
	    assertTrue(contact.getContactId().equals("CID001"));
	    assertTrue(contact.getFirstName().equals("Jane"));
	    assertTrue(contact.getLastName().equals("Doe"));
	    assertTrue(contact.getPhone().equals("1234567890"));
	    assertTrue(contact.getAddress().equals("2 Tea St. Help, OH 12345"));
	}
	//Test for invalid inputs that don't meet the required conditions
	public void TestContactFailure() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("CID12345678", "Frederickson", "Schrefflerski", "12345678901","45678 The Longest Rd. Farawayville, KS 45678");
		});
	}           	
}