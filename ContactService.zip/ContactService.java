import java.util.ArrayList;

public class ContactService {
	public static void main(String[] args) {
		
	}
	//Contact List
	private ArrayList<Contact> CONTACT_IDS;

	//Constructor
	public ContactService() {
		CONTACT_IDS = new ArrayList<>();
	}

    //Add contact
    public boolean add(Contact contact) {
        boolean alreadyPresent = false;
        for (Contact c : CONTACT_IDS) {
            if (c.equals(contact)) {
                alreadyPresent = true;
            }
        }
        //If not already present print added successfully message else print already present
        if (!alreadyPresent) {
        	CONTACT_IDS.add(contact);
            System.out.println("Contact Added Successfully!");
            return true;
        } 
        else {
            System.out.println("Contact already present");
            return false;
        }
    }

    //Delete contact
    public boolean remove(String contactId) {
        for (Contact c : CONTACT_IDS) {
            if (c.getContactId().equals(contactId)) {
            	CONTACT_IDS.remove(c);
                System.out.println("Contact removed Successfully!");
                return true;
            }
        }
        System.out.println("Contact not present");
        return false;
    }

   //Update contact
    public boolean update(String contactId, String firstName, String lastName, String phone, String address) {
        for (Contact c : CONTACT_IDS) {
            if (c.getContactId().equals(contactId)) {
                if (!firstName.equals(""))
                    c.setFirstName(firstName);
                if (!lastName.equals(""))
                    c.setLastName(lastName);
                if (!phone.equals(""))
                    c.setPhone(phone);
                System.out.println("Contact updated Successfully!");
                return true;
            }
        }
        System.out.println("Contact not present");
        return false;
    }

}