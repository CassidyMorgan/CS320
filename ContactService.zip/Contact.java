import java.util.ArrayList;
import java.util.List;


public class Contact {
	public static void main(String[] args) {
		
	}

	//Creating array list for contacts
	private static List<String> CONTACT_IDS = new ArrayList<String>();
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		this.setContactId(contactId);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setPhone(phone);
		this.setAddress(address);		
	}

	public String getContactId() {
		return contactId;
	}

	//make this method private so that is remains not updatable
	private void setContactId(String contactId) {
		//If Contact ID already assigned print not updatable message
		if (this.contactId != null && contactId.length() != 0) {
			System.out.println("Contact ID is not updatable.");			
		} 
		
		//Else if Contact ID string is not unique print not available message
		else if (CONTACT_IDS.contains(contactId)) {
			System.out.println("Contact ID: " + contactId + " is not available.");			
		} 
		
		//Else if Contact ID is null or length is equal to 0 print invalid message
		else if (contactId == null || contactId.length() == 0) {
			System.out.println("Contact ID invalid: Shall not be null.");			
		} 
		//Else if Contact ID length is greater than 10 print invalid message
		else if (contactId.length() > 10) {
			System.out.println("Contact ID invalid: Cannot be no longer than 10 characters.");			
		} 
		//Else assign to contactId
		else {
			this.contactId = contactId;
		}
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		//If first name is null or the length is greater than 10 print invalid message
		if (firstName == null || firstName.length() > 10) {
			System.out.println("First Name invalid: Cannot be more than 10 characters and shall not be null.");			
		} 
		
		//Else assign to First Name
		else {
			this.firstName = firstName;
		}
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		//If last name null or last name length is greater than 10 print invalid message
		if (lastName == null || lastName.length() > 10) {
			System.out.println("Last Name invalid: Cannot be more than 10 characters and shall not be null.");
		} 
		
		//Else assign to Last Name
		else {
			this.lastName = lastName;
		}
	}


	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		//If phone number is equal to 10 and not null assign to phone
		if (phone.length() == 10 && phone != null) {
			this.phone = phone;			
		} 
		
		//Else print invalid message 
		else {
			System.out.println("Phone Number invalid: Must be exactly 10 digits and shall not be null.");
		}
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		//If address is null or address length is greater than 30 print invalid message
		if (address == null || address.length() > 30) {
			System.out.println("Address invalid: Cannot be more than 30 character and shall not be null.");
		} 
		
		//Else assign to address
		else {
			this.address = address;
		}
	}
}